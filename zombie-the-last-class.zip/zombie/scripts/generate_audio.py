"""สร้างเพลงประกอบ (bgm.wav) และเสียงประกอบ (sfx/*.wav) แบบ procedural ด้วย numpy
ไม่ต้องใช้ไฟล์ภายนอก - ถ้ามีไฟล์จริง ให้วางทับชื่อเดิมใน public/audio ได้เลย"""
import pathlib, wave
import numpy as np

SR = 44100
OUT = pathlib.Path(__file__).resolve().parent.parent / "public" / "audio"
(OUT / "sfx").mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(7)
TAU = 2 * np.pi

def save(name, x, peak=0.9):
    x = np.asarray(x, dtype=np.float64)
    x = x / (np.max(np.abs(x)) + 1e-9) * peak
    with wave.open(str(OUT / name), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((x * 32767).astype(np.int16).tobytes())

def T(d): return np.arange(int(SR * d)) / SR
def noise(n): return rng.standard_normal(n)
def lp(x, k):
    k = max(1, int(k)); c = np.cumsum(np.insert(x, 0, 0.0)); y = (c[k:] - c[:-k]) / k
    return np.concatenate([np.full(k - 1, y[0]), y])
def hp(x, k): return x - lp(x, k)
def thump(d, f0=110, f1=40, decay=0.12):
    t = T(d); f = f1 + (f0 - f1) * np.exp(-t * 18)
    return np.sin(TAU * np.cumsum(f) / SR) * np.exp(-t / decay)
def place(buf, x, t0, amp=1.0):
    i = int(t0 * SR)
    if i >= len(buf): return
    j = min(len(buf), i + len(x)); buf[i:j] += x[: j - i] * amp

# ---------------- SFX ----------------
t = T(2.5)
save("sfx/bell.wav", (np.sin(TAU*2100*t) + .6*np.sin(TAU*3170*t) + .4*np.sin(TAU*4300*t)) * (0.5 + 0.5*np.sign(np.sin(TAU*18*t))) * np.exp(-t/1.4))
t = T(2.4); x = np.zeros(len(t))
place(x, (np.sin(TAU*880*t)+.3*np.sin(TAU*1760*t))[:int(1.4*SR)]*np.exp(-t[:int(1.4*SR)]/0.6), 0)
place(x, (np.sin(TAU*659*t)+.3*np.sin(TAU*1318*t))[:int(1.7*SR)]*np.exp(-t[:int(1.7*SR)]/0.8), 0.7)
save("sfx/chime.wav", x)
t = T(4.0); f = 750 + 150*np.sin(TAU*0.6*t)
save("sfx/siren.wav", np.tanh(2.2*np.sin(TAU*np.cumsum(f)/SR)) * np.minimum(1, t/0.3) * np.minimum(1, (4-t)/0.5))
t = T(1.4); save("sfx/thud.wav", thump(1.4, 95, 32, .25)*1.2 + lp(noise(len(t)), 40)*np.exp(-t/.08)*0.8)
t = T(1.6); gate = np.repeat((rng.random(int(1.6*24)) > 0.45).astype(float), SR//24)[:len(t)]
gate = np.pad(gate, (0, len(t)-len(gate)))
saw = 2*((100*t) % 1) - 1
save("sfx/flicker.wav", (np.tanh(3*saw) * 0.6 + hp(noise(len(t)), 6) * 0.35) * gate)
x = np.zeros(SR*5)
for k in range(9):
    tt = T(0.16); place(x, lp(noise(len(tt)), 60) * np.exp(-tt/0.035) * 3, 0.25 + k*0.5, 1.0 if k % 2 else 0.8)
save("sfx/steps.wav", x)
t = T(3.6); fr = 80 * np.exp(t * 2.7)
save("sfx/riser.wav", (np.sin(TAU*np.cumsum(fr)/SR)*0.5 + hp(noise(len(t)), 8)*0.8) * (t/3.6)**2.2 * np.minimum(1, (3.6-t)/0.05))
t = T(3.0); x = thump(3.0, 90, 28, .5)*1.3 + lp(noise(len(t)), 30)*np.exp(-t/.35)*1.2 + hp(noise(len(t)), 5)*np.exp(-t/.04)*0.8
x += np.sin(TAU*45*t)*np.exp(-t/1.0)*0.7; save("sfx/impact.wav", x)
t = T(1.3); h = np.sin(np.pi*t/1.3)**2
save("sfx/whoosh.wav", lp(noise(len(t)), 14) * h + hp(noise(len(t)), 30) * h * 0.4)
t = T(2.2); x = np.sin(TAU*120*t)*0.12 + np.sin(TAU*60*t)*0.1
place(x, hp(noise(int(.05*SR)), 4)*np.exp(-T(.05)/.01)*3, 0.0); place(x, hp(noise(int(.05*SR)), 4)*np.exp(-T(.05)/.01)*2, 0.12)
save("sfx/click.wav", x * np.minimum(1, (2.2-t)/0.3))
t = T(1.0); save("sfx/stamp.wav", thump(1.0, 160, 55, .12)*1.2 + hp(noise(len(t)), 8)*np.exp(-t/.03) + lp(noise(len(t)), 20)*np.exp(-t/.1)*0.6)
t = T(0.7); x = np.zeros(len(t)); i = 0
while i < len(t):
    L = int(rng.uniform(0.01, 0.07)*SR); seg = np.sign(np.sin(TAU*rng.uniform(80, 1800)*t[:L])) if rng.random() > .4 else noise(L)
    x[i:i+L] = seg[:len(x[i:i+L])] * rng.uniform(.3, 1); i += L + int(rng.uniform(0, .03)*SR)
save("sfx/glitch.wav", x * np.exp(-t/0.5))
x = np.zeros(int(3.4*SR))
for k in range(3):
    place(x, thump(.5, 75, 38, .11), k*1.05, 1.0); place(x, thump(.5, 70, 36, .1), k*1.05 + 0.27, 0.7)
save("sfx/heartbeat.wav", x)

# ---------------- BGM (90 s) ----------------
D = 90; n = SR * D; t = np.arange(n) / SR
def seg(a, b, fi=1.0, fo=1.0): return np.clip((t - a)/fi, 0, 1) * np.clip((b - t)/fo, 0, 1)
bgm = np.zeros(n)
drone = np.sin(TAU*55*t + 0.8*np.sin(TAU*0.07*t)) + 0.6*np.sin(TAU*55.4*t) + 0.4*np.sin(TAU*110.2*t) + 0.25*np.sin(TAU*82.4*t)
dmask = 1 - 0.9 * seg(82.2, 85.4, 0.3, 0.3)
bgm += 0.35 * drone * (0.4 + 0.6*np.clip(t/80, 0, 1)) * dmask
trem = 0.7 + 0.3*np.sin(TAU*0.25*t)
amin = np.sin(TAU*220*t) + np.sin(TAU*261.63*t) + np.sin(TAU*329.63*t)
eerie = np.sin(TAU*220*t) + np.sin(TAU*233.08*t) + 0.5*np.sin(TAU*466.16*t)
bgm += 0.10 * amin * trem * seg(0, 14, 2, 2)
bgm += 0.10 * eerie * trem * seg(45, 65, 3, 3)
bgm += 0.12 * amin * trem * seg(65, 82, 4, 0.3) * np.clip((t - 65)/17, 0.2, 1)
def kick(t0, a): place(bgm, thump(0.4, 120, 42, 0.13), t0, a)
def hat(t0, a): place(bgm, hp(noise(int(.06*SR)), 5) * np.exp(-T(.06)/.012), t0, a)
tt = 12.0
while tt < 25: kick(tt, 0.5 + 0.5*(tt-12)/13); kick(tt+0.3, 0.3); tt += 1.0
tt = 25.0
while tt < 45: kick(tt, 0.75); hat(tt+0.27, 0.12); hat(tt+0.0, 0.08); tt += 60/110
tt = 45.0
while tt < 65: kick(tt, 0.35); tt += 2.0
tt = 65.0
while tt < 82: kick(tt, 0.5 + 0.4*(tt-65)/17); hat(tt+0.33, 0.12); tt += 60/(80 + 25*(tt-65)/17)
# riser สู่ชื่อเรื่อง + ปิดท้าย
ri = (t > 84) & (t < 85.5); rr = np.clip((t - 84)/1.5, 0, 1)
bgm += ri * hp(noise(n), 8) * rr**2 * 0.5
place(bgm, thump(3.0, 85, 28, 0.8)*1.4, 85.5, 1.0)
bgm *= np.clip((D - t)/1.5, 0, 1)
save("bgm.wav", bgm, 0.85)
print("audio generated in", OUT)
