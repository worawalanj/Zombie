"""สร้างเสียงพากย์ภาษาไทยจาก src/script.json ด้วย edge-tts (ต้องต่ออินเทอร์เน็ต)
  pip install edge-tts
  python3 scripts/generate_voice.py
สคริปต์จะเขียน src/voiceManifest.json เพื่อให้วิดีโอเล่นเฉพาะเสียงที่สร้างสำเร็จ"""
import asyncio, json, pathlib, shutil, subprocess, sys
try:
    import edge_tts
except ImportError:
    sys.exit("กรุณาติดตั้งก่อน: pip install edge-tts")

ROOT = pathlib.Path(__file__).resolve().parent.parent
cues = json.load(open(ROOT / "src/script.json", encoding="utf-8"))["cues"]
VOICES = {"narrator": ("th-TH-NiwatNeural", "-8%", "-6Hz"), "pa": ("th-TH-PremwadeeNeural", "+0%", "+0Hz")}
out = ROOT / "public/audio/vo"; out.mkdir(parents=True, exist_ok=True)

def duration(path):
    if not shutil.which("ffprobe"): return None
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(path)], capture_output=True, text=True)
    try: return float(r.stdout.strip())
    except ValueError: return None

async def main():
    ok = []
    for c in cues:
        v, rate, pitch = VOICES[c["voice"]]
        path = out / f'{c["id"]}.mp3'
        try:
            await edge_tts.Communicate(c["text"], v, rate=rate, pitch=pitch).save(str(path))
            ok.append(c["id"]); d = duration(path)
            warn = f"  ⚠ ยาว {d:.1f}s > {c['d']}s (ปรับ rate หรือ d ใน script.json)" if d and d > c["d"] + 0.2 else ""
            print("ok  ", c["id"], warn)
        except Exception as e:
            print("fail", c["id"], e)
    json.dump({"ids": ok}, open(ROOT / "src/voiceManifest.json", "w"))
    print(f"สร้างเสียงสำเร็จ {len(ok)}/{len(cues)} ไฟล์")

asyncio.run(main())
