# ZOMBIE: THE LAST CLASS — Remotion Trailer (9:16, 90 วินาที)

## ติดตั้ง
ต้องมี Node.js 18+ และ Python 3 (สำหรับสร้างเสียง)

```bash
npm install
```

## ดูตัวอย่างแบบ Live
```bash
npm run dev          # เปิด Remotion Studio -> เลือก ZombieTrailer
```

## สร้างเสียง
```bash
npm run assets       # เพลงประกอบ + SFX (procedural, ไม่ต้องต่อเน็ต) - แถมมาในโปรเจกต์แล้ว
pip install edge-tts
npm run voice        # เสียงพากย์ไทย (ต้องต่อเน็ต) -> public/audio/vo/*.mp3
```
ถ้าไม่รัน `npm run voice` วิดีโอจะเรนเดอร์ได้ตามปกติ แต่ไม่มีเสียงพากย์ (มีคำบรรยายครบ)

## Export MP4
```bash
npm run render       # -> out/zombie-the-last-class.mp4  (1080x1920, 30fps, H.264)
npm run build:all    # สร้างเสียง + พากย์ + เรนเดอร์ ในคำสั่งเดียว
```

## โครงสร้าง
- `src/config.ts` — ไทม์ไลน์ซีน, รายชื่อ 28 คน/4 ทีม, ตาราง SFX
- `src/script.json` — บทพากย์/คำบรรยายทั้งหมด (แก้ข้อความและเวลาได้ที่นี่ที่เดียว)
- `src/scenes/Scene1..6.tsx` — แต่ละซีนเป็น Component แยก
- `src/fx.tsx` — Glitch, Film Grain, Camera Shake, Flash, Subtitles
- `src/Figure.tsx` — ตัวละครซิลูเอต
- `public/audio/bgm.wav`, `public/audio/sfx/*.wav` — แทนที่ด้วยไฟล์จริงได้ (ใช้ชื่อเดิม)

## หมายเหตุ
- ฟอนต์ Prompt (ไทย) โหลดจาก Google Fonts ตอนเรนเดอร์ครั้งแรก ต้องต่อเน็ต
- ภาพทั้งหมดเป็นเวกเตอร์ (SVG/CSS) แทนภาพประกอบจริง เปลี่ยนเป็นรูปได้ด้วย `<Img src={staticFile(...)}/>`
