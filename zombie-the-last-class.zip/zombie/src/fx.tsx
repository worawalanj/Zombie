import React from "react";
import {AbsoluteFill, interpolate, random, useCurrentFrame, useVideoConfig} from "remotion";
import {fontFamily} from "./fonts";
import {CUES, Cue} from "./config";

const clampOpt = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

/** opacity 0→1→0 ในช่วงเฟรม a..b */
export const win = (f: number, a: number, b: number, fade = 12) =>
  interpolate(f, [a, a + fade, b - fade, b], [0, 1, 1, 0], clampOpt);
export const ramp = (f: number, a: number, b: number) => interpolate(f, [a, b], [0, 1], clampOpt);

export const SceneFade: React.FC<{dur: number; inF?: number; outF?: number; children: React.ReactNode}> = ({
  dur, inF = 12, outF = 12, children,
}) => {
  const f = useCurrentFrame();
  const o = interpolate(f, [0, Math.max(inF, 1), dur - outF, dur], [inF ? 0 : 1, 1, 1, 0], clampOpt);
  return <AbsoluteFill style={{opacity: o}}>{children}</AbsoluteFill>;
};

export const Shake: React.FC<{amount?: number; children: React.ReactNode}> = ({amount = 6, children}) => {
  const f = useCurrentFrame();
  const x = ((Math.sin(f * 1.7) + Math.sin(f * 3.1 + 1)) * amount) / 2;
  const y = ((Math.cos(f * 2.3) + Math.sin(f * 4.1)) * amount) / 2;
  const r = Math.sin(f * 0.9) * amount * 0.03;
  return (
    <AbsoluteFill style={{transform: `translate(${x}px,${y}px) rotate(${r}deg) scale(1.05)`}}>{children}</AbsoluteFill>
  );
};

export const Flash: React.FC<{at: number; len?: number; color?: string}> = ({at, len = 9, color = "#fff"}) => {
  const f = useCurrentFrame();
  const o = interpolate(f, [at, at + 1, at + len], [0, 0.95, 0], clampOpt);
  return <AbsoluteFill style={{background: color, opacity: o, pointerEvents: "none"}} />;
};

export const Grain: React.FC<{opacity?: number}> = ({opacity = 0.16}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: "none", mixBlendMode: "overlay", opacity}}>
      <svg width={1080} height={1920}>
        <filter id="grain">
          <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves={2} seed={f % 7} stitchTiles="stitch" />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="1080" height="1920" filter="url(#grain)" />
      </svg>
    </AbsoluteFill>
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background:
        "radial-gradient(ellipse at 50% 50%, rgba(0,0,0,0) 45%, rgba(0,0,0,0.75) 100%), repeating-linear-gradient(0deg, rgba(0,0,0,0.10) 0px, rgba(0,0,0,0.10) 1px, transparent 1px, transparent 4px)",
    }}
  />
);

export const GlitchText: React.FC<{
  text: string; size: number; color?: string; weight?: number; intensity?: number;
  letterSpacing?: number; shadow?: string;
}> = ({text, size, color = "#fff", weight = 800, intensity = 0.35, letterSpacing = 0, shadow}) => {
  const f = useCurrentFrame();
  const burst = random(`gb${Math.floor(f / 3)}`) > 1 - intensity;
  const dx = burst ? (random(`gx${f}`) - 0.5) * 36 : 1.5;
  const top = Math.floor(random(`gt${f}`) * 60);
  const base: React.CSSProperties = {fontFamily, fontSize: size, fontWeight: weight, letterSpacing, lineHeight: 1.1, whiteSpace: "nowrap"};
  return (
    <div style={{position: "relative", display: "inline-block", ...base}}>
      <span style={{color, textShadow: shadow, clipPath: burst ? `inset(${top}% 0 ${Math.max(0, 40 - top)}% 0)` : undefined, transform: burst ? `translateX(${-dx / 2}px)` : undefined}}>{text}</span>
      <span style={{position: "absolute", left: 0, top: 0, color: "#ff2a3a", mixBlendMode: "screen", opacity: 0.8, transform: `translateX(${-dx}px)`}}>{text}</span>
      <span style={{position: "absolute", left: 0, top: 0, color: "#22d3ee", mixBlendMode: "screen", opacity: 0.7, transform: `translateX(${dx}px)`}}>{text}</span>
    </div>
  );
};

/** คำบรรยายภาษาไทย (ใช้เวลา absolute ของวิดีโอ) */
export const Subtitles: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = f / fps;
  const cue: Cue | undefined = CUES.find((c) => s >= c.t && s < c.t + c.d && c.sub !== false);
  if (!cue) return null;
  const local = s - cue.t;
  const o = Math.min(1, local / 0.25, (cue.d - local) / 0.25);
  const isPA = cue.voice === "pa";
  return (
    <AbsoluteFill style={{justifyContent: "flex-end", alignItems: "center", paddingBottom: 230, paddingLeft: 80, paddingRight: 80}}>
      <div
        style={{
          opacity: Math.max(0, o), fontFamily, fontSize: 54, fontWeight: 600, lineHeight: 1.4, textAlign: "center",
          color: isPA ? "#ff8a8a" : "#f4f6fa", textShadow: "0 4px 20px rgba(0,0,0,0.95)",
          background: "rgba(0,0,0,0.5)", padding: "12px 30px", borderRadius: 14, maxWidth: 920, overflowWrap: "break-word",
        }}
      >
        {isPA ? "[ประกาศ] " : ""}{cue.text}
      </div>
    </AbsoluteFill>
  );
};
