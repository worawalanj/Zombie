import {loadFont} from "@remotion/google-fonts/Prompt";

export const {fontFamily} = loadFont("normal", {
  weights: ["400", "600", "800"],
  subsets: ["thai", "latin"],
});
