import script from "./script.json";
import voice from "./voiceManifest.json";

export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const DURATION_SEC = 90;
export const TOTAL_FRAMES = FPS * DURATION_SEC;

export const COLORS = {
  black: "#050608", navy: "#0a1428", deep: "#0d1b33", gray: "#8a93a3",
  red: "#d4202a", redGlow: "#ff3b3b", white: "#eef2f8",
};

export type Cue = {id: string; t: number; d: number; text: string; voice: "narrator" | "pa"; sub?: boolean};
export const CUES = script.cues as unknown as Cue[];
export const VOICE_IDS: string[] = voice.ids;

// เวลาเริ่ม / ความยาวของแต่ละซีน (วินาที) - รวม 90 วินาที
export const SCENES = [
  {id: "s1", from: 0, dur: 12},
  {id: "s2", from: 12, dur: 13},
  {id: "s3", from: 25, dur: 20},
  {id: "s4", from: 45, dur: 20},
  {id: "s5", from: 65, dur: 17},
  {id: "s6", from: 82, dur: 8},
] as const;

// เสียงประกอบ: t = วินาทีแบบ absolute, f = ชื่อไฟล์ใน public/audio/sfx
export const SFX: {t: number; f: string; v: number}[] = [
  {t: 0.2, f: "bell", v: 0.6}, {t: 8.4, f: "chime", v: 0.8}, {t: 11.0, f: "siren", v: 0.3},
  {t: 12.0, f: "thud", v: 1}, {t: 13.0, f: "flicker", v: 0.6}, {t: 16.0, f: "flicker", v: 0.6},
  {t: 19.0, f: "steps", v: 0.5}, {t: 21.7, f: "riser", v: 0.8}, {t: 22.2, f: "impact", v: 1},
  {t: 25.0, f: "whoosh", v: 0.7}, {t: 26.0, f: "whoosh", v: 0.5}, {t: 30.5, f: "whoosh", v: 0.5},
  {t: 35.0, f: "whoosh", v: 0.5}, {t: 39.5, f: "whoosh", v: 0.5}, {t: 44.4, f: "impact", v: 0.6},
  {t: 45.0, f: "thud", v: 0.8}, {t: 51.0, f: "whoosh", v: 0.5}, {t: 52.0, f: "stamp", v: 0.9},
  {t: 56.0, f: "click", v: 0.6}, {t: 60.5, f: "glitch", v: 0.9}, {t: 60.6, f: "impact", v: 0.9},
  {t: 65.0, f: "steps", v: 0.6}, {t: 70.5, f: "click", v: 0.8}, {t: 74.0, f: "impact", v: 0.9},
  {t: 77.8, f: "glitch", v: 0.8}, {t: 77.9, f: "impact", v: 0.7}, {t: 82.2, f: "heartbeat", v: 0.9},
  {t: 84.2, f: "riser", v: 0.8}, {t: 85.5, f: "impact", v: 1}, {t: 85.5, f: "glitch", v: 0.8},
];

export const TEAMS = [
  {key: "plan", th: "ทีมวางแผน", en: "PLANNING", role: "วางแผนเส้นทางหนีและจุดซ่อน", color: "#3b82f6",
    names: ["ภูผา", "ภูมิ", "ภูเบศ", "เนส", "ไกด์", "พลับ", "นิว"]},
  {key: "watch", th: "ทีมเฝ้าระวัง", en: "LOOKOUT", role: "เฝ้าประตู หน้าต่าง และทางเดิน", color: "#ef4444",
    names: ["กวิน", "มิว", "ชมพู่", "ปริ้น", "ฝัน", "แบม", "เทียน"]},
  {key: "medic", th: "ทีมพยาบาล", en: "MEDIC", role: "ดูแลผู้บาดเจ็บและขวัญกำลังใจ", color: "#22c55e",
    names: ["การ์ตูน", "พลอย", "อิ่ม", "ต้นข้าว", "นุ่น", "พะแพน", "กาสะลอง"]},
  {key: "supply", th: "ทีมเสบียง", en: "SUPPLY", role: "รวบรวมอาหาร น้ำ และอุปกรณ์", color: "#f59e0b",
    names: ["แก้ม", "แป้ง", "น้ำหนาว", "ลูกตาล", "อริส", "แพนเค้ก", "กระปุก"]},
];
