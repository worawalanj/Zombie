import React from "react";
import {useCurrentFrame} from "remotion";

export type Kind = "sit" | "stand" | "walk" | "panic" | "zombie";
type P = {
  x: number; y: number; s?: number; kind?: Kind; phase?: number; shirt?: string;
  flip?: boolean; opacity?: number; speed?: number; head?: string;
};
const pt = (x: number, y: number, len: number, deg: number) => ({
  x: x + Math.sin((deg * Math.PI) / 180) * len,
  y: y + Math.cos((deg * Math.PI) / 180) * len,
});

/** ตัวละครซิลูเอต (origin = เท้า, สูง ~310 หน่วย) */
export const Figure: React.FC<P> = ({
  x, y, s = 1, kind = "stand", phase = 0, shirt = "#aeb7c4", flip = false, opacity = 1, speed = 1, head = "#12151d",
}) => {
  const f = useCurrentFrame();
  const t = (f / 30) * Math.PI * 2 * speed + phase;
  const moving = kind === "walk" || kind === "zombie" || kind === "panic";
  const swing = moving ? Math.sin(t) * 26 : 0;
  const bob = kind === "sit" ? Math.sin(t * 0.7) * 3 : moving ? Math.abs(Math.sin(t)) * -7 : 0;
  const tilt = kind === "zombie" ? 10 + Math.sin(t * 0.5) * 4 : kind === "panic" ? Math.sin(t) * 5 : 0;
  const hip = -120, sh = -228;
  const lLeg = pt(-16, hip, 120, swing), rLeg = pt(16, hip, 120, -swing);
  let lArm = pt(-36, sh, 95, 6), rArm = pt(36, sh, 95, -6);
  if (kind === "walk") { lArm = pt(-36, sh, 95, -swing * 0.8); rArm = pt(36, sh, 95, swing * 0.8); }
  if (kind === "panic") { lArm = pt(-36, sh, 100, -150 + Math.sin(t * 2) * 15); rArm = pt(36, sh, 100, 150 - Math.sin(t * 2) * 15); }
  if (kind === "zombie") { lArm = pt(-36, sh, 105, -100 - Math.sin(t) * 8); rArm = pt(36, sh, 105, 100 + Math.sin(t) * 8); }
  const body = kind === "zombie" ? "#56606c" : shirt;
  const limb = {strokeWidth: 22, strokeLinecap: "round" as const};
  return (
    <g opacity={opacity} transform={`translate(${x},${y + bob}) scale(${flip ? -s : s},${s})`}>
      <g transform={`rotate(${tilt},0,${hip})`}>
        {kind !== "sit" && (
          <>
            <line x1={-16} y1={hip} x2={lLeg.x} y2={lLeg.y} stroke="#0b0e15" {...limb} />
            <line x1={16} y1={hip} x2={rLeg.x} y2={rLeg.y} stroke="#0b0e15" {...limb} />
          </>
        )}
        <rect x={-36} y={-252} width={72} height={136} rx={28} fill={body} stroke="rgba(120,160,255,0.25)" strokeWidth={3} />
        <line x1={-36} y1={sh} x2={lArm.x} y2={lArm.y} stroke={body} {...limb} />
        <line x1={36} y1={sh} x2={rArm.x} y2={rArm.y} stroke={body} {...limb} />
        <circle cx={0} cy={-284} r={30} fill={head} stroke="rgba(120,160,255,0.3)" strokeWidth={3} />
        {kind === "zombie" && (
          <>
            <circle cx={-10} cy={-286} r={4.5} fill="#ff2a2a" style={{filter: "drop-shadow(0 0 7px #ff2020)"}} />
            <circle cx={10} cy={-286} r={4.5} fill="#ff2a2a" style={{filter: "drop-shadow(0 0 7px #ff2020)"}} />
          </>
        )}
      </g>
    </g>
  );
};
