import React from "react";
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from "remotion";
import {CUES, FPS, SCENES, SFX, VOICE_IDS} from "./config";
import {Grain, Subtitles, Vignette} from "./fx";
import {fontFamily} from "./fonts";
import {Scene1} from "./scenes/Scene1";
import {Scene2} from "./scenes/Scene2";
import {Scene3} from "./scenes/Scene3";
import {Scene4} from "./scenes/Scene4";
import {Scene5} from "./scenes/Scene5";
import {Scene6} from "./scenes/Scene6";

const MAP: Record<string, React.FC<{dur: number}>> = {s1: Scene1, s2: Scene2, s3: Scene3, s4: Scene4, s5: Scene5, s6: Scene6};

export const Trailer: React.FC = () => {
  const frame = useCurrentFrame();
  const s = frame / FPS;
  const talking = CUES.some((c) => VOICE_IDS.includes(c.id) && s >= c.t - 0.1 && s < c.t + c.d);
  return (
    <AbsoluteFill style={{background: "#000", fontFamily}}>
      {SCENES.map((sc) => {
        const C = MAP[sc.id];
        return (
          <Sequence key={sc.id} from={sc.from * FPS} durationInFrames={sc.dur * FPS}>
            <C dur={sc.dur * FPS} />
          </Sequence>
        );
      })}
      <Grain />
      <Vignette />
      <Subtitles />
      {/* เพลงประกอบ (ลดเสียงลงเมื่อมีเสียงพากย์) */}
      <Audio src={staticFile("audio/bgm.wav")} volume={talking ? 0.35 : 0.7} />
      {SFX.map((e, i) => (
        <Sequence key={i} from={Math.round(e.t * FPS)}>
          <Audio src={staticFile(`audio/sfx/${e.f}.wav`)} volume={e.v * 0.8} />
        </Sequence>
      ))}
      {CUES.filter((c) => VOICE_IDS.includes(c.id)).map((c) => (
        <Sequence key={c.id} from={Math.round(c.t * FPS)}>
          <Audio src={staticFile(`audio/vo/${c.id}.mp3`)} volume={1} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
