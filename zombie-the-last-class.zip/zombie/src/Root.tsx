import React from "react";
import {Composition} from "remotion";
import {Trailer} from "./Trailer";
import {FPS, HEIGHT, TOTAL_FRAMES, WIDTH} from "./config";

export const Root: React.FC = () => (
  <Composition
    id="ZombieTrailer"
    component={Trailer}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
  />
);
