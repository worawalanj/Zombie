import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {FPS} from "../config";
import {Figure} from "../Figure";
import {SceneFade, Shake, ramp} from "../fx";
import {fontFamily} from "../fonts";

const ROWS = [
  {y: 1190, s: 0.72}, {y: 1470, s: 0.95}, {y: 1810, s: 1.25},
];

export const Scene1: React.FC<{dur: number}> = ({dur}) => {
  const f = useCurrentFrame();
  const s = f / FPS;
  const zoom = interpolate(f, [0, dur], [1, 1.12]);
  const alarm = s > 8.3;
  const pulse = alarm ? (Math.sin((s - 8.3) * 9) + 1) / 2 : 0;
  const bannerX = interpolate(f, [8.3 * FPS, 8.3 * FPS + 10], [-1100, 0], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  return (
    <SceneFade dur={dur} inF={20} outF={10}>
      <Shake amount={alarm ? 9 : 2}>
        <AbsoluteFill style={{transform: `scale(${zoom})`}}>
          <svg width={1080} height={1920} viewBox="0 0 1080 1920">
            <defs>
              <linearGradient id="wall1" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0" stopColor="#101a2c" /><stop offset="1" stopColor="#1d2a40" />
              </linearGradient>
              <linearGradient id="floor1" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0" stopColor="#1a1f2a" /><stop offset="1" stopColor="#07090e" />
              </linearGradient>
              <linearGradient id="beam1" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0" stopColor="#bcd4ff" stopOpacity="0.30" /><stop offset="1" stopColor="#bcd4ff" stopOpacity="0" />
              </linearGradient>
            </defs>
            <rect width={1080} height={1000} fill="url(#wall1)" />
            <rect y={1000} width={1080} height={920} fill="url(#floor1)" />
            {/* ไฟเพดาน + แสงลง */}
            {[200, 540, 880].map((x) => (
              <g key={x}>
                <polygon points={`${x - 110},40 ${x + 110},40 ${x + 300},1000 ${x - 300},1000`} fill="url(#beam1)" />
                <rect x={x - 130} y={30} width={260} height={18} rx={6} fill="#dfe9ff" opacity={0.9} />
              </g>
            ))}
            {/* กระดานดำ */}
            <rect x={130} y={250} width={680} height={400} rx={10} fill="#0e2a24" stroke="#4a3b2a" strokeWidth={14} />
            <text x={470} y={350} textAnchor="middle" fontFamily={fontFamily} fontSize={52} fontWeight={600} fill="#d7e6df">ฟิสิกส์ ม.6 : แรงและการเคลื่อนที่</text>
            <text x={470} y={470} textAnchor="middle" fontFamily={fontFamily} fontSize={100} fontWeight={800} fill="#b8d4c8">F = ma</text>
            <text x={470} y={580} textAnchor="middle" fontFamily={fontFamily} fontSize={40} fill="#8fb0a2">วันศุกร์ที่ 13 • คาบที่ 7</text>
            {/* นาฬิกา */}
            <circle cx={540} cy={160} r={58} fill="#e8edf5" stroke="#222" strokeWidth={6} />
            <line x1={540} y1={160} x2={540} y2={118} stroke="#111" strokeWidth={6} strokeLinecap="round" />
            <line x1={540} y1={160} x2={540 + Math.sin(s * 0.5) * 34} y2={160 - Math.cos(s * 0.5) * 34} stroke="#c22" strokeWidth={4} strokeLinecap="round" />
            {/* ประตูและป้ายห้อง */}
            <rect x={850} y={430} width={190} height={570} fill="#2b2220" stroke="#10151f" strokeWidth={8} />
            <rect x={875} y={470} width={140} height={150} fill="#0d1624" />
            <rect x={840} y={340} width={210} height={70} rx={8} fill="#13244a" stroke="#c9d6f0" strokeWidth={4} />
            <text x={945} y={392} textAnchor="middle" fontFamily={fontFamily} fontSize={44} fontWeight={800} fill="#fff">ม.6/1</text>
            {/* นักเรียน + โต๊ะเรียน */}
            {ROWS.map((r, ri) =>
              [0, 1, 2, 3, 4].map((ci) => {
                const x = 120 + ci * 210 + (ri % 2) * 20;
                return (
                  <g key={`${ri}-${ci}`}>
                    <Figure x={x} y={r.y} s={r.s} kind="sit" phase={ri * 2 + ci * 1.3} shirt={ci % 2 ? "#c7cfdb" : "#aab4c4"} />
                    <rect x={x - 80 * r.s} y={r.y - 125 * r.s} width={160 * r.s} height={22 * r.s} rx={4} fill="#3a2f28" />
                    <rect x={x - 70 * r.s} y={r.y - 103 * r.s} width={140 * r.s} height={75 * r.s} fill="#17120f" />
                  </g>
                );
              })
            )}
          </svg>
          {/* ไฟสีแดงเตือนภัย */}
          <AbsoluteFill style={{background: `radial-gradient(circle at 50% 50%, rgba(255,0,20,${0.05 + pulse * 0.4}), rgba(120,0,0,${pulse * 0.5}) 100%)`, mixBlendMode: "screen"}} />
        </AbsoluteFill>
      </Shake>
      {/* ป้ายเวลา */}
      <div style={{position: "absolute", left: 80, top: 110, fontFamily, color: "#cfd8e6", opacity: ramp(f, 20, 45) * (alarm ? 0.4 : 1)}}>
        <div style={{fontSize: 38, letterSpacing: 6, fontWeight: 600}}>08:15 น.</div>
        <div style={{fontSize: 30, color: "#7f8aa0"}}>โรงเรียน • ห้อง ม.6/1</div>
      </div>
      {/* แบนเนอร์ประกาศฉุกเฉิน */}
      {alarm && (
        <div style={{position: "absolute", left: 0, top: 260, width: 1080, transform: `translateX(${bannerX}px)`, background: "rgba(190,15,25,0.92)", padding: "26px 80px", fontFamily, color: "#fff", fontSize: 76, fontWeight: 800, boxShadow: "0 0 60px rgba(255,0,0,0.6)"}}>
          ประกาศฉุกเฉิน
          <div style={{fontSize: 34, fontWeight: 400, opacity: 0.9}}>EMERGENCY ANNOUNCEMENT</div>
        </div>
      )}
    </SceneFade>
  );
};
