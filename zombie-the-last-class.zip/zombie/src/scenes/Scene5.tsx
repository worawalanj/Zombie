import React from "react";
import {AbsoluteFill, interpolate, random, useCurrentFrame} from "remotion";
import {FPS} from "../config";
import {Figure} from "../Figure";
import {Flash, GlitchText, SceneFade, Shake, ramp} from "../fx";
import {fontFamily} from "../fonts";

const clampO = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;
const OPEN = 165, T1 = 270, T2 = 384;

export const Scene5: React.FC<{dur: number}> = ({dur}) => {
  const f = useCurrentFrame();
  const open = interpolate(f, [OPEN, OPEN + 30], [0.02, 1], clampO);
  const beam = ramp(f, OPEN, OPEN + 20) * (random(`bm${Math.floor(f / 2)}`) > 0.92 ? 0.5 : 1);
  const redFlick = f > T1 ? 0.12 + 0.1 * Math.sin(f * 0.4) : 0;
  const camY = interpolate(f, [0, dur], [0, -50]);
  const students = Array.from({length: 14}).map((_, i) => {
    const fromLeft = i % 2 === 0;
    const row = Math.floor(i / 2) % 2, col = Math.floor(i / 4);
    const tx = fromLeft ? 140 + col * 130 + row * 60 : 940 - col * 130 - row * 60;
    const delay = i * 8;
    const p = interpolate(f, [delay, delay + 120], [0, 1], clampO);
    const e = 1 - Math.pow(1 - p, 2);
    const x = (fromLeft ? -120 : 1200) + (tx - (fromLeft ? -120 : 1200)) * e;
    return {x, y: 1360 + row * 120 + (i % 3) * 20, walking: p < 1, i, row};
  });
  return (
    <SceneFade dur={dur} inF={14} outF={10}>
      <Shake amount={f > T1 ? 6 : 2}>
        <AbsoluteFill style={{background: "linear-gradient(180deg,#05070d,#0a0f1c 60%,#04050a)", transform: `translateY(${camY}px) scale(1.05)`}}>
          <svg width={1080} height={1920}>
            <defs>
              <linearGradient id="beam5" x1="0" y1="1" x2="0" y2="0">
                <stop offset="0" stopColor="#cfe0ff" stopOpacity="0.0" /><stop offset="1" stopColor="#cfe0ff" stopOpacity="0.32" />
              </linearGradient>
            </defs>
            {/* ม่านเวที */}
            <polygon points="0,0 230,0 150,900 0,1000" fill="#3a0b12" />
            <polygon points="1080,0 850,0 930,900 1080,1000" fill="#3a0b12" />
            <rect x={0} y={1000} width={1080} height={920} fill="#080b13" />
            <rect x={0} y={960} width={1080} height={40} fill="#1a1410" />
            <text x={540} y={150} textAnchor="middle" fontFamily={fontFamily} fontSize={44} fontWeight={600} fill="#7d8798" letterSpacing={6}>หอประชุมโรงเรียน</text>
            {/* จอ */}
            <rect x={84} y={270} width={912} height={532} fill="#0a0a0e" stroke="#2a2f3a" strokeWidth={10} />
            {/* ลำแสงโปรเจกเตอร์ */}
            <polygon points="500,1720 580,1720 996,800 84,800" fill="url(#beam5)" opacity={beam} />
            {/* เก้าอี้ */}
            {[0, 1, 2, 3].map((r) => (
              <g key={r}>
                {Array.from({length: 9}).map((_, c) => (
                  <rect key={c} x={50 + c * 110 - r * 6} y={1130 + r * 190} width={84 + r * 8} height={70 + r * 10} rx={12} fill="#0e1424" stroke="#1b2540" strokeWidth={3} />
                ))}
              </g>
            ))}
            {students.map((st) => (
              <Figure key={st.i} x={st.x} y={st.y} s={0.95} kind={st.walking ? "walk" : "stand"} phase={st.i} speed={1.2} shirt="#7f8ba0" head="#0c0f16" opacity={0.95} />
            ))}
          </svg>
          {/* หน้าจอที่เปิดขึ้น */}
          <div style={{position: "absolute", left: 90, top: 276, width: 900, height: 520, overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center"}}>
            <div style={{width: 900, height: 520, transform: `scaleY(${open})`, background: "radial-gradient(circle at 50% 50%, #12233f, #060912)", position: "relative", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", fontFamily}}>
              {f >= OPEN + 30 && f < T1 && (
                <svg width={900} height={520} style={{position: "absolute", left: 0, top: 0, opacity: 0.5}}>
                  <filter id="stat"><feTurbulence type="fractalNoise" baseFrequency="0.9" seed={f % 9} /><feColorMatrix type="saturate" values="0" /></filter>
                  <rect width="900" height="520" filter="url(#stat)" />
                </svg>
              )}
              {f >= T1 && (
                <div style={{textAlign: "center"}}>
                  <GlitchText text="THE EXPERIMENT" size={84} color="#f2f6ff" intensity={0.35} shadow="0 0 30px rgba(120,170,255,0.8)" />
                  <br />
                  <GlitchText text="IS NOT OVER" size={84} color="#ff3b46" intensity={0.35} shadow="0 0 30px rgba(255,0,0,0.7)" />
                </div>
              )}
              {f >= T2 && (
                <div style={{position: "absolute", left: 0, right: 0, bottom: 0, top: 0, background: "rgba(3,6,14,0.93)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center"}}>
                  <GlitchText text="CLASS 6/1 —" size={64} color="#f2f6ff" intensity={0.3} />
                  <GlitchText text="ALL SUBJECTS" size={72} color="#ff3b46" intensity={0.3} shadow="0 0 30px rgba(255,0,0,0.7)" />
                  <GlitchText text="CONFIRMED" size={72} color="#ff3b46" intensity={0.3} shadow="0 0 30px rgba(255,0,0,0.7)" />
                </div>
              )}
            </div>
          </div>
          <AbsoluteFill style={{background: `rgba(255,0,20,${redFlick})`, mixBlendMode: "screen"}} />
        </AbsoluteFill>
      </Shake>
      <Flash at={T1} len={7} />
      <Flash at={T2} len={7} color="#ff2a3a" />
    </SceneFade>
  );
};
