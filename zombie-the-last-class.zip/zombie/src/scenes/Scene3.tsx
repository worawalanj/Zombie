import React from "react";
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame} from "remotion";
import {COLORS, FPS, TEAMS} from "../config";
import {SceneFade, Shake, win, ramp} from "../fx";
import {fontFamily} from "../fonts";

const PHASE_START = [30, 165, 300, 435];
const PHASE_LEN = 135;

export const Scene3: React.FC<{dur: number}> = ({dur}) => {
  const f = useCurrentFrame();
  const gridA = (f * 0.5) % 120;
  const gridB = (f * 1.4) % 240;
  const sweep = ((f * 9) % 1400) - 160;
  const assigned = TEAMS.reduce((n, _t, ti) => {
    const st = PHASE_START[ti];
    return n + (f > st ? Math.min(7, Math.floor((f - st) / 8) + 1) : 0);
  }, 0);
  return (
    <SceneFade dur={dur} inF={12} outF={10}>
      <Shake amount={3}>
        <AbsoluteFill style={{background: `linear-gradient(180deg, ${COLORS.navy}, #060b16)`}}>
          <svg width={1080} height={1920} style={{position: "absolute"}}>
            <defs>
              <pattern id="g1" width={120} height={120} patternUnits="userSpaceOnUse">
                <path d="M120 0H0V120" fill="none" stroke="#1d3358" strokeWidth={1.5} />
              </pattern>
              <pattern id="g2" width={240} height={240} patternUnits="userSpaceOnUse">
                <path d="M240 0H0V240" fill="none" stroke="#2a4a7d" strokeWidth={2.5} />
              </pattern>
            </defs>
            <rect x={-240} y={-240 + gridA} width={1560} height={2400} fill="url(#g1)" opacity={0.7} />
            <rect x={-240} y={-240 + gridB} width={1560} height={2400} fill="url(#g2)" opacity={0.45} />
            {Array.from({length: 26}).map((_, i) => (
              <circle key={i} cx={random(`px${i}`) * 1080} cy={(random(`py${i}`) * 2000 - f * (0.6 + random(`ps${i}`) * 1.2) + 4000) % 1920} r={2 + random(`pr${i}`) * 4} fill="#7fa6e8" opacity={0.35} />
            ))}
          </svg>
          <div style={{position: "absolute", left: 0, top: sweep, width: 1080, height: 6, background: "rgba(90,150,255,0.35)", boxShadow: "0 0 40px rgba(90,150,255,0.7)"}} />
        </AbsoluteFill>
      </Shake>
      {/* หัวข้อ */}
      <div style={{position: "absolute", left: 80, top: 110, fontFamily, opacity: ramp(f, 0, 20)}}>
        <div style={{fontSize: 34, letterSpacing: 10, color: COLORS.red, fontWeight: 800}}>SURVIVAL</div>
        <div style={{fontSize: 40, color: "#cfd8e6", fontWeight: 600}}>แบ่งหน้าที่ {assigned} / 28 คน</div>
      </div>
      {/* ทีม */}
      {TEAMS.map((team, ti) => {
        const st = PHASE_START[ti];
        const o = win(f, st, st + PHASE_LEN + 8, 10);
        if (o <= 0) return null;
        const lf = f - st;
        const slide = interpolate(lf, [0, 14], [90, 0], {extrapolateRight: "clamp", extrapolateLeft: "clamp"});
        return (
          <AbsoluteFill key={team.key} style={{opacity: o, fontFamily}}>
            <div style={{position: "absolute", left: 80, top: 270, transform: `translateX(${-slide}px)`}}>
              <div style={{width: 120, height: 8, background: team.color, marginBottom: 18, boxShadow: `0 0 20px ${team.color}`}} />
              <div style={{fontSize: 120, fontWeight: 800, color: "#fff", lineHeight: 1.15}}>{team.th}</div>
              <div style={{fontSize: 38, letterSpacing: 12, color: team.color, fontWeight: 600}}>{team.en}</div>
              <div style={{fontSize: 40, color: "#aeb9cc", marginTop: 8, maxWidth: 920}}>{team.role}</div>
            </div>
            {team.names.map((name, k) => {
              const p = spring({frame: lf - 10 - k * 7, fps: FPS, config: {damping: 14, stiffness: 140}});
              const col = k % 2, row = Math.floor(k / 2);
              const x = k === 6 ? 320 : 80 + col * 480;
              return (
                <div key={name} style={{position: "absolute", left: x, top: 640 + row * 150, width: 440, height: 116, opacity: p, transform: `scale(${0.7 + 0.3 * p}) translateY(${(1 - p) * 40}px)`, display: "flex", alignItems: "center", gap: 24, padding: "0 26px", boxSizing: "border-box", background: "rgba(10,20,40,0.78)", border: `3px solid ${team.color}`, borderRadius: 18, boxShadow: `0 0 28px ${team.color}55`}}>
                  <div style={{width: 56, height: 56, borderRadius: 28, background: team.color, color: "#04070d", fontSize: 30, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center"}}>{ti * 7 + k + 1}</div>
                  <div style={{fontSize: 52, fontWeight: 600, color: "#fff", whiteSpace: "nowrap"}}>{name}</div>
                </div>
              );
            })}
          </AbsoluteFill>
        );
      })}
      {/* จุด 28 คน */}
      <svg width={1080} height={1920} style={{position: "absolute", pointerEvents: "none"}}>
        {Array.from({length: 28}).map((_, k) => {
          const ti = Math.floor(k / 7);
          const lit = f > PHASE_START[ti] + 10 + (k % 7) * 8;
          const finale = f > 570 ? 0.5 + 0.5 * Math.sin((f - 570) * 0.6) : 0;
          return <circle key={k} cx={86 + (k % 14) * 69} cy={1310 + Math.floor(k / 14) * 64} r={19} fill={lit ? TEAMS[ti].color : "#18233a"} opacity={lit ? 0.95 : 0.6} style={{filter: lit ? `drop-shadow(0 0 ${8 + finale * 14}px ${TEAMS[ti].color})` : undefined}} />;
        })}
      </svg>
    </SceneFade>
  );
};
