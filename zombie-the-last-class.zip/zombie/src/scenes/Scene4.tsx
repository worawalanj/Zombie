import React from "react";
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame} from "remotion";
import {COLORS, FPS} from "../config";
import {Flash, GlitchText, SceneFade, Shake, ramp, win} from "../fx";
import {fontFamily} from "../fonts";

const clampO = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;
const REVEAL = 465;

const Flask: React.FC<{x: number; y: number; c: string; f: number; k: number}> = ({x, y, c, f, k}) => (
  <g>
    <polygon points={`${x - 14},${y - 120} ${x + 14},${y - 120} ${x + 60},${y} ${x - 60},${y}`} fill={c} opacity={0.35} stroke="#9fd" strokeWidth={3} />
    <rect x={x - 14} y={y - 170} width={28} height={52} fill="none" stroke="#9fd" strokeWidth={3} />
    {[0, 1, 2].map((i) => (
      <circle key={i} cx={x - 14 + i * 14} cy={y - 10 - ((f * (0.6 + i * 0.3) + k * 17 + i * 31) % 70)} r={4 + i} fill={c} opacity={0.8} />
    ))}
  </g>
);

export const Scene4: React.FC<{dur: number}> = ({dur}) => {
  const f = useCurrentFrame();
  const zoom = interpolate(f, [0, 360], [1, 1.14], clampO);
  const flick = random(`lf${Math.floor(f / 2)}`) > 0.93 ? 0.55 : 1;
  const docIn = spring({frame: f - 180, fps: FPS, config: {damping: 16}});
  const docZoom = interpolate(f, [360, 465], [1, 1.25], clampO);
  const boxIn = spring({frame: f - 270, fps: FPS, config: {damping: 13}});
  const stamp = spring({frame: f - 215, fps: FPS, config: {damping: 9, stiffness: 160}});
  const barSlide = interpolate(f, [REVEAL, REVEAL + 14], [0, 700], clampO);
  const revealed = f >= REVEAL;
  const labO = 1 - ramp(f, 150, 200);
  const dimDoc = revealed ? interpolate(f, [REVEAL, REVEAL + 20], [1, 0.2], clampO) : 1;
  return (
    <SceneFade dur={dur} inF={14} outF={10}>
      <Shake amount={revealed ? 14 : 3}>
        <AbsoluteFill style={{background: "radial-gradient(circle at 50% 40%, #0b2a2f, #04080d 75%)"}}>
          {/* ห้องแล็บ */}
          <AbsoluteFill style={{opacity: labO, transform: `scale(${zoom})`}}>
            <svg width={1080} height={1920}>
              <rect x={0} y={1180} width={1080} height={740} fill="#070d14" />
              {[520, 820, 1120].map((y, si) => (
                <g key={y}>
                  <rect x={60} y={y} width={960} height={16} fill="#1c2a35" />
                  {[0, 1, 2, 3].map((i) => (
                    <Flask key={i} x={150 + i * 240} y={y} c={["#22e0a0", "#38bdf8", "#a3e635", "#22d3ee"][(i + si) % 4]} f={f} k={i + si * 4} />
                  ))}
                </g>
              ))}
              <rect x={0} y={1180} width={1080} height={26} fill="#122431" />
              <polygon points="0,260 1080,200 1080,300 0,360" fill="#e8b400" opacity={0.9} />
              <text x={540} y={300} textAnchor="middle" fontFamily={fontFamily} fontSize={52} fontWeight={800} fill="#111" transform="rotate(-3.2 540 300)">ห้องปฏิบัติการวิทยาศาสตร์ • ห้ามเข้า</text>
            </svg>
            <AbsoluteFill style={{background: `rgba(0,0,0,${1 - flick})`}} />
          </AbsoluteFill>
          {/* เอกสารลับ */}
          {f >= 175 && (
            <AbsoluteFill style={{opacity: dimDoc * ramp(f, 175, 195), justifyContent: "center", alignItems: "center"}}>
              <div style={{width: 780, height: 1040, background: "#d8d3c3", transform: `translateY(${(1 - docIn) * 900}px) rotate(-3deg) scale(${docZoom})`, padding: 60, boxSizing: "border-box", fontFamily, color: "#16140f", boxShadow: "0 30px 80px rgba(0,0,0,0.8)", position: "relative", marginTop: -140}}>
                <div style={{fontSize: 56, fontWeight: 800}}>รายงานการทดลองลับ</div>
                <div style={{fontSize: 30, letterSpacing: 6, color: "#6b6556"}}>PROJECT 6/1 • CONFIDENTIAL</div>
                {[0, 1, 2, 3, 4].map((i) => (
                  <div key={i} style={{height: 14, background: "#8d8774", marginTop: 26, width: `${88 - (i % 3) * 14}%`}} />
                ))}
                <div style={{fontSize: 40, fontWeight: 600, marginTop: 60}}>ผู้ทดลองหลัก:</div>
                <div style={{position: "relative", height: 90, marginTop: 6}}>
                  <div style={{position: "absolute", left: 0, top: 0, fontSize: 80, fontWeight: 800, color: "#b3141c"}}>อริส</div>
                  <div style={{position: "absolute", left: 0, top: 6, width: 520, height: 80, background: "#08080a", transform: `translateX(${barSlide}px)`}} />
                </div>
                <div style={{fontSize: 40, fontWeight: 600, marginTop: 30}}>สถานะตัวอย่าง:</div>
                <div style={{height: 70, background: "#08080a", marginTop: 8, width: 460}} />
                {[0, 1, 2].map((i) => (
                  <div key={i} style={{height: 14, background: "#8d8774", marginTop: 26, width: `${80 - i * 12}%`}} />
                ))}
                <div style={{position: "absolute", right: 40, top: 120, transform: `rotate(-14deg) scale(${stamp > 0 ? 2.6 - 1.6 * stamp : 0})`, opacity: Math.min(1, stamp * 2), border: "8px solid #c4161f", color: "#c4161f", fontSize: 64, fontWeight: 800, padding: "6px 24px", borderRadius: 10}}>ลับที่สุด</div>
              </div>
            </AbsoluteFill>
          )}
          {/* กล่องตัวอย่าง */}
          {f >= 270 && f < 380 && (
            <div style={{position: "absolute", right: 70, top: 1130, width: 420, opacity: boxIn * win(f, 270, 380, 14), transform: `scale(${0.6 + 0.4 * boxIn}) rotate(4deg)`, fontFamily}}>
              <div style={{height: 220, background: "linear-gradient(180deg,#3a4350,#1a2029)", borderRadius: 18, border: "4px solid #566274", position: "relative", boxShadow: "0 0 50px rgba(34,224,160,0.45)"}}>
                <div style={{position: "absolute", left: 40, top: 40, width: 70, height: 140, borderRadius: "12px 12px 30px 30px", background: "#22e0a0", boxShadow: "0 0 36px #22e0a0", opacity: 0.55 + 0.4 * Math.sin(f * 0.3)}} />
                <div style={{position: "absolute", left: 140, top: 50, color: "#e8edf5", fontSize: 40, fontWeight: 800}}>SAMPLE</div>
                <div style={{position: "absolute", left: 140, top: 100, color: "#ff5560", fontSize: 56, fontWeight: 800}}>06-A</div>
              </div>
              <div style={{textAlign: "center", marginTop: 10, color: "#cfd8e6", fontSize: 34}}>กล่องตัวอย่างปริศนา</div>
            </div>
          )}
        </AbsoluteFill>
      </Shake>
      {/* เผยชื่อ */}
      {revealed && (
        <AbsoluteFill style={{justifyContent: "center", alignItems: "center", opacity: ramp(f, REVEAL + 6, REVEAL + 20), background: "rgba(0,0,0,0.35)"}}>
          <div style={{fontFamily, color: "#9aa3b5", fontSize: 40, letterSpacing: 14, marginBottom: 10}}>SUBJECT</div>
          <GlitchText text="อริส" size={290} color="#e0262f" intensity={0.55} shadow="0 0 60px rgba(255,0,0,0.65)" />
          <div style={{fontFamily, color: "#cfd8e6", fontSize: 44, marginTop: 18}}>ARIS • ผู้เกี่ยวข้องกับต้นเหตุ</div>
        </AbsoluteFill>
      )}
      <Flash at={REVEAL} color="#ff2a3a" len={10} />
    </SceneFade>
  );
};
