import React from "react";
import {AbsoluteFill, interpolate, spring, useCurrentFrame} from "remotion";
import {FPS} from "../config";
import {Flash, GlitchText, SceneFade, Shake} from "../fx";
import {fontFamily} from "../fonts";

const clampO = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;
const SLAM = 105;

export const Scene6: React.FC<{dur: number}> = ({dur}) => {
  const f = useCurrentFrame();
  const beat = (t: number) => Math.exp(-Math.pow((f - t) / 5, 2));
  const heart = Math.max(beat(15), beat(30), beat(60), beat(72), beat(95)) * (f < SLAM ? 1 : 0);
  const p = spring({frame: f - SLAM, fps: FPS, config: {damping: 12, stiffness: 120}});
  const tag = interpolate(f, [150, 180], [0, 1], clampO);
  return (
    <SceneFade dur={dur} inF={0} outF={14}>
      <AbsoluteFill style={{background: "#000"}}>
        <AbsoluteFill style={{background: `radial-gradient(circle at 50% 50%, rgba(220,20,30,${heart * 0.35}), rgba(0,0,0,0) 55%)`}} />
        {f >= SLAM && (
          <Shake amount={f < SLAM + 20 ? 18 : 2}>
            <AbsoluteFill style={{justifyContent: "center", alignItems: "center", fontFamily}}>
              <div style={{textAlign: "center", transform: `scale(${1.35 - 0.35 * p})`, opacity: Math.min(1, p * 2)}}>
                <GlitchText text="ZOMBIE:" size={190} color="#e0262f" intensity={f < SLAM + 40 ? 0.6 : 0.15} shadow="0 0 70px rgba(255,0,0,0.6)" />
                <br />
                <GlitchText text="THE LAST CLASS" size={98} color="#f2f4f8" intensity={f < SLAM + 40 ? 0.6 : 0.15} letterSpacing={2} />
              </div>
              <div style={{marginTop: 60, fontSize: 60, color: "#aeb7c6", letterSpacing: 4, opacity: tag, transform: `translateY(${(1 - tag) * 20}px)`}}>
                คาบสุดท้ายก่อนวันสิ้นโลก
              </div>
            </AbsoluteFill>
          </Shake>
        )}
        <Flash at={SLAM} len={12} />
      </AbsoluteFill>
    </SceneFade>
  );
};
