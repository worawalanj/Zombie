import React from "react";
import {AbsoluteFill, interpolate, random, useCurrentFrame} from "remotion";
import {FPS} from "../config";
import {Figure} from "../Figure";
import {Flash, GlitchText, SceneFade, Shake, ramp} from "../fx";

const VX = 540, VY = 820;
const xL = (d: number) => VX - 560 * d;
const xR = (d: number) => VX + 560 * d;
const yT = (d: number) => VY - 780 * d;
const yB = (d: number) => VY + 500 * d;
const DS = [2.2, 1.3, 0.8, 0.55, 0.4, 0.3, 0.22, 0.17, 0.13, 0.1];
const poly = (p: number[][]) => p.map((q) => q.join(",")).join(" ");

const ZOMBIES = [
  {d0: 0.12, d1: 0.5, x: -0.15, ph: 0}, {d0: 0.1, d1: 0.4, x: 0.4, ph: 1.1},
  {d0: 0.09, d1: 0.36, x: -0.5, ph: 2.2}, {d0: 0.14, d1: 0.55, x: 0.6, ph: 3.3}, {d0: 0.08, d1: 0.3, x: 0.05, ph: 4.4},
];
const STUDENTS = [
  {d0: 0.5, d1: 1.15, x: -0.45, ph: 0.5}, {d0: 0.55, d1: 1.2, x: 0.15, ph: 1.7}, {d0: 0.6, d1: 1.1, x: 0.6, ph: 2.9},
];

export const Scene2: React.FC<{dur: number}> = ({dur}) => {
  const f = useCurrentFrame();
  const s = f / FPS;
  const dark = interpolate(f, [0, 240], [0.15, 0.82], {extrapolateRight: "clamp"});
  const thr = interpolate(s, [2, 8], [0.1, 0.75], {extrapolateRight: "clamp", extrapolateLeft: "clamp"});
  const walk = ramp(f, 60, dur - 40);
  const redPulse = (Math.sin(s * 5) + 1) / 2;
  const titleF = 306;
  const showTitle = f >= titleF;
  const titleScale = interpolate(f, [titleF, titleF + 8], [1.5, 1], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  return (
    <SceneFade dur={dur} inF={10} outF={8}>
      <Shake amount={interpolate(f, [0, 300, 360], [5, 12, 22], {extrapolateRight: "clamp"})}>
        <AbsoluteFill>
          <svg width={1080} height={1920} viewBox="0 0 1080 1920">
            <rect width={1080} height={1920} fill="#070a12" />
            <polygon points={poly([[VX, VY], [xL(2.2), yT(2.2)], [xR(2.2), yT(2.2)]])} fill="#10151f" />
            <polygon points={poly([[VX, VY], [xL(2.2), yB(2.2)], [xR(2.2), yB(2.2)]])} fill="#1b2230" />
            {DS.slice(0, -1).map((a, i) => {
              const b = DS[i + 1];
              const shade = i % 2 ? "#141b2a" : "#18212f";
              const lockers = [0.08, 0.4, 0.72].map((r, k) => {
                const mk = (side: "L" | "R") => {
                  const X = side === "L" ? xL : xR;
                  const x0 = X(a) + (X(b) - X(a)) * r, x1 = X(a) + (X(b) - X(a)) * (r + 0.26);
                  const t0 = yT(a) + (yT(b) - yT(a)) * r, t1 = yT(a) + (yT(b) - yT(a)) * (r + 0.26);
                  const b0 = yB(a) + (yB(b) - yB(a)) * r, b1 = yB(a) + (yB(b) - yB(a)) * (r + 0.26);
                  const h0 = b0 - t0, h1 = b1 - t1;
                  return <polygon key={`${side}${k}`} points={poly([[x0, t0 + h0 * 0.3], [x1, t1 + h1 * 0.3], [x1, b1 - h1 * 0.08], [x0, b0 - h0 * 0.08]])} fill="#1f3550" stroke="#0a1018" strokeWidth={3} />;
                };
                return [mk("L"), mk("R")];
              });
              const mid = (a + b) / 2;
              const dead = s > 2 + i * 1.0;
              const on = !dead && random(`L${i}${Math.floor(f / (2 + (i % 3)))}`) > thr * 0.6;
              return (
                <g key={i}>
                  <polygon points={poly([[xL(a), yT(a)], [xL(b), yT(b)], [xL(b), yB(b)], [xL(a), yB(a)]])} fill={shade} />
                  <polygon points={poly([[xR(a), yT(a)], [xR(b), yT(b)], [xR(b), yB(b)], [xR(a), yB(a)]])} fill={shade} />
                  {lockers}
                  <ellipse cx={VX} cy={yT(mid) + 30 * mid} rx={170 * mid} ry={16 * mid} fill="#e8f0ff" opacity={on ? 0.95 : 0.06} />
                  {on && <ellipse cx={VX} cy={yB(mid) - 10} rx={340 * mid} ry={60 * mid} fill="#a9c6ff" opacity={0.12} />}
                </g>
              );
            })}
            {ZOMBIES.map((z, i) => {
              const d = z.d0 + (z.d1 - z.d0) * walk;
              return <Figure key={`z${i}`} x={VX + z.x * 520 * d} y={yB(d)} s={2.35 * d} kind="zombie" phase={z.ph} speed={0.55} opacity={Math.min(1, 0.35 + d * 1.2)} />;
            })}
            {STUDENTS.map((st, i) => {
              const d = st.d0 + (st.d1 - st.d0) * ramp(f, 20, dur - 20);
              return <Figure key={`p${i}`} x={VX + st.x * 520 * d} y={yB(d)} s={2.35 * d} kind="panic" phase={st.ph} speed={1.6} />;
            })}
          </svg>
          <AbsoluteFill style={{background: `rgba(0,0,0,${dark})`}} />
          <AbsoluteFill style={{background: `radial-gradient(circle at 50% 40%, rgba(255,0,20,${0.08 + redPulse * 0.25}), rgba(0,0,0,0) 70%)`, mixBlendMode: "screen"}} />
        </AbsoluteFill>
      </Shake>
      {showTitle && (
        <AbsoluteFill style={{justifyContent: "center", alignItems: "center", background: "rgba(0,0,0,0.38)"}}>
          <div style={{transform: `scale(${titleScale})`, textAlign: "center"}}>
            <GlitchText text="THE OUTBREAK" size={112} color="#f2f4f8" intensity={0.5} shadow="0 0 40px rgba(0,0,0,0.9)" />
            <br />
            <GlitchText text="HAS BEGUN" size={140} color="#e0262f" intensity={0.5} shadow="0 0 50px rgba(255,0,0,0.6)" />
          </div>
        </AbsoluteFill>
      )}
      <Flash at={titleF} />
    </SceneFade>
  );
};
